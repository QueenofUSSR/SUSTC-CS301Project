#ifndef __SERVER_H
#define __SERVER_H

#include "main.h"

extern  TIM_HandleTypeDef htim5;

void SetJointAngle(float angle);

#endif
